package com.dextracker;

import com.google.android.gms.games.Games;
import com.google.example.games.basegameutils.GameHelper;
import com.google.example.games.basegameutils.GameHelper.GameHelperListener;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

public class MainMenu extends Activity implements ActionResolver, GameHelperListener {

	//GameHelper
	private GameHelper gameHelper;
	
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		//LeaderboardCode
				if (gameHelper == null) {
				      gameHelper = new GameHelper(this, GameHelper.CLIENT_GAMES);
				      gameHelper.enableDebugLog(true);
				    }
				    gameHelper.setup(this);
				
		
		
		setContentView(R.layout.activity_main_menu);
	}
	
	
	@Override
	protected void onStart(){
		super.onStart();
		gameHelper.onStart(this);
	}
	@Override
	public void onStop(){
		super.onStop();
		gameHelper.onStop();
	}
	@Override
	public void onActivityResult(int request, int response, Intent data) {
		super.onActivityResult(request, response, data);
		gameHelper.onActivityResult(request, response, data);
	}
	 public void btnGameOne_onClick(View v)
	    {
	    	Intent intent = new Intent(this, GameOne.class);
	    	startActivity(intent);
	    }
	    public void btnGameTwo_onClick(View v)
	    {
	    	Intent intent = new Intent(this, GameTwo.class);
	    	startActivity(intent);
	    }
	    public void btnGameThree_onClick(View v)
	    {
	    	Intent intent = new Intent(this, GameTwo.class);
	    	startActivity(intent);
	    }
	    public void btnLeaderboard_onClick(View v)
	    {
			if (getSignedInGPGS()) getLeaderboardGPGS();
			else loginGPGS();
	    }
//	    public void btnSettings_onClick(View v)
//	    {
//	    	Intent intent = new Intent(this, Settings.class);
//	    	startActivity(intent);
//	    }
//	    

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main_menu, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
	@Override
	public boolean getSignedInGPGS() {
		return gameHelper.isSignedIn();
	}
	
	@Override
	public void loginGPGS() {
		try {
			runOnUiThread(new Runnable(){
				public void run() {
					gameHelper.beginUserInitiatedSignIn();
				}
			});
		} catch (final Exception ex) {
		}
		
	}
	@Override
	public void submitScoreGPGS(int score) {
		Games.Leaderboards.submitScore(gameHelper.getApiClient(), "CgkIpJrS6ZcWEAIQAQ", score);
		
	}
	@Override
	public void unlockAchievementGPGS(String achievementId) {
		Games.Achievements.unlock(gameHelper.getApiClient(), achievementId);
		
	}
	@Override
	public void getLeaderboardGPGS() {
		  if (gameHelper.isSignedIn()) {
			    startActivityForResult(Games.Leaderboards.getLeaderboardIntent(gameHelper.getApiClient(), "CgkIpJrS6ZcWEAIQAQ"), 100);
			  }
			  else if (!gameHelper.isConnecting()) {
			    loginGPGS();
			  }
	}
	
	@Override
	public void getAchievementsGPGS() {
		  if (gameHelper.isSignedIn()) {
			    startActivityForResult(Games.Achievements.getAchievementsIntent(gameHelper.getApiClient()), 101);
			  }
			  else if (!gameHelper.isConnecting()) {
			    loginGPGS();
			  }
		
	}
	@Override
	public void onSignInFailed() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void onSignInSucceeded() {
		// TODO Auto-generated method stub
		
	}
}
